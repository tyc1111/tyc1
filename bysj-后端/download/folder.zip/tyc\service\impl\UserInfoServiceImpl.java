package com.example.springbootcodegenerator.tyc.service.impl;

import com.example.springbootcodegenerator.tyc.entity.UserInfo;
import com.example.springbootcodegenerator.tyc.mapper.UserInfoMapper;
import com.example.springbootcodegenerator.tyc.service.IUserInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
* @author tyc
*/
@Service
public class UserInfoServiceImpl implements IUserInfoService {
    @Autowired
    private UserInfoMapper UserInfoMapper1;

    /*
    * 单个ID删除操作
    * */
    @Override
    public void delete(Integer id){
        UserInfoMapper1.delete(id);
    }

    /*
    * 批量删除操作
    * */
    @Override
    public void deleteAll(List<Integer> ids) {
        UserInfoMapper1.deleteAll(ids);
    }

    /*
    * 全部查询操作
    * */
    @Override
    public List<UserInfo> selectAll() {
        return UserInfoMapper1.selectAll();
    }

    /*
    * 单体查询操作
    * */
    @Override
    public UserInfo select(Integer id) {
        return UserInfoMapper1.select(id);
    }

    /*
    * 插入操作
    * */
    @Override
    public void insert(UserInfo UserInfo1) {
        UserInfoMapper1.insert(UserInfo1);
    }

    /*
    * 更新操作
    * */
    @Override
    public void update(UserInfo UserInfo1) {
        UserInfoMapper1.update(UserInfo1);
    }

}

