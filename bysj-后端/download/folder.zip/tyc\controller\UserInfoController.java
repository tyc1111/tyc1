package com.example.springbootcodegenerator.tyc.controller;

import com.example.springbootcodegenerator.tyc.entity.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.springbootcodegenerator.util.Result;
import java.util.List;
import com.example.springbootcodegenerator.tyc.service.IUserInfoService;
import org.springframework.web.bind.annotation.RequestMapping;

    import org.springframework.web.bind.annotation.RestController;

/**
* @author tyc
*/
@RestController
@RequestMapping("/tyc/user-info")

public class UserInfoController {
        @Autowired
        private IUserInfoService IUserInfoService1;

        /*
        * 单体删除操作
        * */
        @DeleteMapping("/delete/{id}")
        public Result delete(@PathVariable Integer id){
                IUserInfoService1.delete(id);
                return Result.success();

        }

        /*
        * 批量删除操作
        * */
        @DeleteMapping("/deleteAll/{ids}")
        public Result deleteAll(@PathVariable List<Integer> ids){
                IUserInfoService1.deleteAll(ids);
                return Result.success();
        }

        /*
        * 全部查询操作
        * */
        @GetMapping("/selectALl")
        public Result selectAll(){
                List<UserInfo> UserInfo1 = IUserInfoService1.selectAll();
                return Result.success(UserInfo1);
        }

        /*
        * 单体查询操作
        * */
        @GetMapping("/select/{id}")
        public Result select(@PathVariable Integer id){
                UserInfo UserInfo1 = IUserInfoService1.select(id);
                return Result.success(UserInfo1);
        }

        /*
        * 插入操作
        * */
        @PostMapping("/insert")
        public Result insert(@RequestBody UserInfo UserInfo1){
                IUserInfoService1.insert(UserInfo1);
                return Result.success();
        }

        @PutMapping("/update")
        public Result update(@RequestBody UserInfo UserInfo1){
                IUserInfoService1.update(UserInfo1);
                return Result.success();
        }

}


