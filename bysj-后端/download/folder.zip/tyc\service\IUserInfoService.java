package com.example.springbootcodegenerator.tyc.service;

import com.example.springbootcodegenerator.tyc.entity.UserInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;
/**
* @author tyc
*/

    public interface IUserInfoService {

        /*
        * 单个ID删除操作
        * */
        void delete(Integer id);

        /*
        * 批量删除操作
        * */
        void deleteAll(List<Integer> ids);

        /*
        * 全部查询操作
        * */
        List<UserInfo> selectAll();

        /*
        * 单体查询操作
        * */
        UserInfo select(Integer id);

        /*
        * 插入操作
        * */
        void insert(UserInfo UserInfo1);

        /*
        * 更新操作
        * */
        void update(UserInfo UserInfo1);
}
