package com.example.springbootcodegenerator.tyc.entity;


    import lombok.AllArgsConstructor;
    import lombok.Data;
    import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
/**
* 
*
* @author tyc
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {



    private Integer userId;

    private String userName;

    private Boolean status;
}