package com.example.springbootcodegenerator.tyc.mapper;

import com.example.springbootcodegenerator.tyc.entity.UserInfo;
import org.apache.ibatis.annotations.*;
import java.util.List;

/**
* @author tyc
*/
@Mapper
public interface UserInfoMapper {

    /*
    * 单个ID删除操作
    * */
    @Delete("delete from user_info where id = #{id}")
    public int delete(Integer id);

    /*
    * 批量删除操作
    * */
    void deleteAll(List<Integer> ids);

    /*
    * 全部查询操作
    * */
    @Select("select * from emp")
    List<UserInfo> selectAll();

    /*
    * 单体查询操作
    * */
    @Select("select * from emp where id = #{id}")
    UserInfo select(Integer id);

    /*
    * 插入操作
    * */
    @Insert("insert into user_info(user_id, user_name, status) " +
    " values (#{userId}, #{userName}, #{status});")
    void insert(UserInfo UserInfo1);

    /*
    * 更新操作
    * */
    void update(UserInfo UserInfo1);




}

